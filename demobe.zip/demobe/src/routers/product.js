import express from "express";
import {
  addProduct,
  deleteProduct,
  getProductbyId,
  getProducts,
  updateProduct,
} from "../controllers/product";

const router = express.Router();

router.get("/products", getProducts);
router.get("/products/:id", getProductbyId);
router.post("/products", addProduct);
router.put("/products/:id", updateProduct);
router.delete("/products/:id", deleteProduct);
/* router.get("/products/:id", (req, res) => {
  console.log("id", req.params.id);
});
router.post("/products", (req, res) => {
  console.log(req.body);
});
router.put("/products", (req, res) => {
  console.log("GET /products");
});
router.delete("/products", (req, res) => {
  console.log("GET /products");
}); */

export default router;
