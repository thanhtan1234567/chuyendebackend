import User from "../model/user";
import { registerSchema } from "../schemas/auth";
import bcryptjs from "bcryptjs";

export const signup = async (req, res) => {
  //lấy dữ liệu user gửi lên
  const { username, password, confirmPassword, email, age } = req.body;
  //kiểm tra xem dữ liệu có hợp lệ không
  const { error } = registerSchema.validate(req.body, { abortEarly: false });
  if (error) {
    const message = error.details.map((message) => message.message);
    return res.status(400).json({
      message: message,
    });
  }
  //kiem tra user ton tai hay chua
  const existUser = await User.findOne({ email });
  if (existUser) {
    return res.status(400).json({
      message: ["Email đã tồn tại"],
    });
  }
  //mã hóa mật khẩu sử dụng bcryptjs
  const hashedPassword = await bcryptjs.hash(password, 10);
  //lưu user vào database
  const user = await User.create({
    username,
    email,
    password: hashedPassword,
    age,
  });
  //trả về thông tin user đã đăng ký(không gửi về mật khẩu)
  user.password = undefined;
  return res.status(201).json({
    user: user,
  });
};

export const signin = async (req, res) => {
  // Lấy dữ liệu user gửi lên
  const { email, password } = req.body;

  // Kiểm tra xem email có tồn tại không
  const user = await User.findOne({ email });
  if (!user) {
    return res.status(400).json({
      message: ["Email không tồn tại"],
    });
  }

  // Kiểm tra mật khẩu
  const isMatch = await bcryptjs.compare(password, user.password);
  if (!isMatch) {
    return res.status(400).json({
      message: ["Mật khẩu không đúng"],
    });
  }

  // Trả về thông tin user đã đăng nhập (không gửi về mật khẩu)
  user.password = undefined;
  return res.status(200).json({
    user: user,
  });
};
export const getUsers = async (req, res) => {
  try {
    const users = await User.find(); // Lấy tất cả người dùng
    res.status(200).json(users); // Trả về danh sách người dùng
  } catch (error) {
    res
      .status(500)
      .json({ message: "Có lỗi xảy ra khi lấy danh sách người dùng." });
  }
};
