// Import model 'product' từ thư mục model để tương tác với MongoDB
import product from "../model/product";

// Controller xử lý việc lấy tất cả sản phẩm
// async/await được sử dụng để xử lý các thao tác bất đồng bộ với database
export const getProducts = async (req, res) => {
  try {
    // Sử dụng phương thức find() để lấy tất cả sản phẩm từ database
    const data = await product.find();
    // Kiểm tra nếu không có sản phẩm nào trong database
    if (data.length === 0) {
      // Trả về status 404 và thông báo không tìm thấy sản phẩm
      return res.status(404).json({ message: "No products found" });
    }
    // Trả về status 200 và dữ liệu sản phẩm nếu tìm thấy
    res.status(200).json(data);
  } catch (error) {
    // Xử lý lỗi nếu có vấn đề khi truy vấn database
    res.status(500).json({
      error: error.message,
    });
  }
};

// Controller xử lý việc lấy một sản phẩm theo ID
export const getProductbyId = async (req, res) => {
  try {
    // Tìm một sản phẩm theo ID được truyền vào từ params URL
    const data = await product.findOne({ _id: req.params.id });
    // Kiểm tra nếu không tìm thấy sản phẩm
    if (!data) {
      // Trả về status 404 nếu không tìm thấy
      return res.status(404).json({ message: "No product found" });
    }
    // Trả về sản phẩm nếu tìm thấy
    res.status(200).json(data);
  } catch (error) {
    // Xử lý lỗi khi truy vấn
    res.status(500).json({
      message: "Không thể tìm sản phẩm",
      error: error.message,
    });
  }
};

// Controller xử lý việc thêm sản phẩm mới
export const addProduct = async (req, res) => {
  try {
    // Tạo instance mới của model product với dữ liệu từ request body và lưu vào database
    const data = await product(req.body).save();
    // Trả về status 201 (Created) và thông tin sản phẩm vừa tạo
    res.status(201).json(data);
  } catch (error) {
    // Xử lý lỗi khi thêm sản phẩm
    res.status(500).json({
      message: "Không thể thêm sản phẩm",
      error: error.message,
    });
  }
};

// Controller xử lý việc xóa sản phẩm
export const deleteProduct = async (req, res) => {
  try {
    // Tìm và xóa sản phẩm theo ID
    const data = await product.findOneAndDelete({ _id: req.params.id });
    // Kiểm tra nếu không tìm thấy sản phẩm để xóa
    if (!data) {
      return res.status(404).json({ message: "No product found" });
    }
    // Trả về thông tin sản phẩm đã xóa
    res.status(200).json(data);
  } catch (error) {
    // Xử lý lỗi khi xóa sản phẩm
    res.status(500).json({
      message: "Không thể xóa sản phẩm",
      error: error.message,
    });
  }
};

// Controller xử lý việc cập nhật sản phẩm
export const updateProduct = async (req, res) => {
  try {
    // Tìm và cập nhật sản phẩm theo ID
    // { new: true } đảm bảo trả về document đã được cập nhật
    const data = await product.findOneAndUpdate(
      { _id: req.params.id }, // điều kiện tìm kiếm theo ID
      req.body, // dữ liệu cập nhật từ request body
      { new: true } // options để trả về document đã cập nhật
    );

    // Kiểm tra nếu không tìm thấy sản phẩm để cập nhật
    if (!data) {
      return res.status(404).json({ message: "Không tìm thấy sản phẩm" });
    }
    // Trả về sản phẩm đã được cập nhật
    res.status(200).json(data);
  } catch (error) {
    // Xử lý lỗi khi cập nhật sản phẩm
    res.status(500).json({
      message: "Không thể cập nhật sản phẩm",
      error: error.message,
    });
  }
};
