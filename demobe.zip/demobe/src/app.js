import express from "express";
import productRouter from "./routers/product";
import authRouter from "./routers/auth";
import { connectDB } from "./config/db";
import dotenv from "dotenv";
import morgan from "morgan";
import cors from "cors";
dotenv.config();
const app = express();
const PORT = process.env.PORT || 8080;
//middleware
app.use(express.json());
app.use(morgan("dev"));
app.use(cors());
//connect db
connectDB(process.env.DB_URI);
//router
app.use("/api", productRouter);
app.use("/api", authRouter);
app.listen(PORT, () => {
  console.log(`Server is running on port ${PORT}`);
});
export const viteNodeApp = app;
