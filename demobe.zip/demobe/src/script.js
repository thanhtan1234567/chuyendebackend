// Hàm để chuyển đổi giữa hai form
function toggleForms() {
  const signupForm = document.getElementById("signupForm");
  const signinForm = document.getElementById("signinForm");
  const formTitle = document.getElementById("formTitle");
  const toggleFormText = document.getElementById("toggleFormText");

  if (signupForm.style.display === "none") {
    signupForm.style.display = "block";
    signinForm.style.display = "none";
    formTitle.textContent = "Đăng Ký";
    toggleFormText.innerHTML =
      'Bạn đã có tài khoản? <a href="#" id="toggleFormLink">Đăng Nhập</a>';
  } else {
    signupForm.style.display = "none";
    signinForm.style.display = "block";
    formTitle.textContent = "Đăng Nhập";
    toggleFormText.innerHTML =
      'Chưa có tài khoản? <a href="#" id="toggleFormLink">Đăng Ký</a>';
  }

  // Cập nhật lại sự kiện cho liên kết chuyển đổi
  document.getElementById("toggleFormLink").addEventListener("click", (e) => {
    e.preventDefault(); // Ngăn chặn hành động mặc định của liên kết
    toggleForms(); // Gọi hàm chuyển đổi
  });
}

// Gọi hàm toggleForms khi trang được tải
document.addEventListener("DOMContentLoaded", () => {
  // Thêm sự kiện cho form đăng ký
  document
    .getElementById("signupForm")
    .addEventListener("submit", async (e) => {
      e.preventDefault(); // Ngăn chặn hành động mặc định của form

      const formData = new FormData(e.target);
      const data = Object.fromEntries(formData);

      try {
        const response = await fetch("http://localhost:8080/api/signup", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        });

        const result = await response.json();
        if (response.ok) {
          alert("Đăng ký thành công!");
          // Có thể chuyển hướng đến trang đăng nhập hoặc trang khác
        } else {
          alert(result.message.join(", "));
        }
      } catch (error) {
        console.error("Có lỗi xảy ra:", error);
      }
    });

  // Thêm sự kiện cho form đăng nhập
  document
    .getElementById("signinForm")
    .addEventListener("submit", async (e) => {
      e.preventDefault(); // Ngăn chặn hành động mặc định của form

      const formData = new FormData(e.target);
      const data = Object.fromEntries(formData);

      try {
        const response = await fetch("http://localhost:8080/api/signin", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify(data),
        });

        const result = await response.json();
        if (response.ok) {
          alert("Đăng nhập thành công!");
          // Có thể chuyển hướng đến trang chính hoặc trang khác
        } else {
          alert(result.message.join(", "));
        }
      } catch (error) {
        console.error("Có lỗi xảy ra:", error);
      }
    });

  // Khởi động với form đăng ký hiển thị
  toggleForms();
});
